import { PiGreaterThan } from "react-icons/pi";
import MovieCard from "./MovieCard";
import spiderman from "../assets/spiderman.png";
import Poster from "../assets/Poster.png";

const FeaturedMovie = ({ title }) => {
  const movies = [
    {
      poster: spiderman,
      title: "Spider-Man: Far From Home",
      releaseYear: 2021,
      imdbRating: 9.2,
      tomatoRating: 92,
      country: "USA",
      genre: ["Animation", "Action", "Adventure"],
    },
    {
      poster: Poster,
      title: "John Wick - The Parabellum",
      releaseYear: 2024,
      imdbRating: 5.2,
      tomatoRating: 82,
      country: "Uk",
      genre: ["Action", "Adventure"],
    },
    {
      poster: spiderman,
      title: "Spider-Man: Far From Home",
      releaseYear: 2021,
      imdbRating: 9.2,
      tomatoRating: 92,
      country: "USA",
      genre: ["Animation", "Action", "Adventure"],
    },
    {
      poster: Poster,
      title: "John Wick - The Parabellum",
      releaseYear: 2024,
      imdbRating: 5.2,
      tomatoRating: 82,
      country: "Uk",
      genre: ["Action", "Adventure"],
    },
  ];
  return (
    <div
      style={{
        paddingInline: "96px",
      }}
    >
      {/* Heading */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          width: "100%",
          color: "black",
        }}
      >
        <h4>{title}</h4>
        <div>
          <span>See More</span>
          <PiGreaterThan />
        </div>
      </div>
      {/* Movies */}
      <div style={{ display: "flex", columnGap: "24px", flexWrap: "wrap" }}>
        {movies.map((value, index) => {
          return <MovieCard key={index} movie={value} />;
        })}
      </div>
    </div>
  );
};

export default FeaturedMovie;
